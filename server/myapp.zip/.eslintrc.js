module.exports = {
  extends: 'airbnb-base',
  globals: {
    process: true,
  },
  rules: {
    'linebreak-style': 0,
    'no-underscore-dangle': 0,
    'no-param-reassign': 0,
  },
};
