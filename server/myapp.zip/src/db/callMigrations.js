const migrations = require('./migrations');

migrations(process.exit);
